package com.shop.constant;

public enum ItemSellStatus {
    SELL,SOLD_OUT //static 필드고 파이널이다.

}
